- Refactor Main.py
- Change design of multiple html files
  - market.html
  - trade_offers.html
  